
DELETE FROM jobs;
DELETE FROM companies;
