
DROP INDEX idx_user_profiles_user_id;
DROP INDEX idx_applications_job_id;
DROP INDEX idx_applications_user_id;
DROP INDEX idx_jobs_company_id;
DROP TABLE applications;
DROP TABLE user_profiles;
DROP TABLE jobs;
DROP TABLE companies;
