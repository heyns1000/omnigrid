
INSERT INTO companies (name, description, website_url, created_at, updated_at) VALUES
('TechFlow Inc', 'A leading fintech company revolutionizing digital payments and blockchain solutions.', 'https://techflow.com', datetime('now'), datetime('now')),
('DataVision Labs', 'Cutting-edge AI and machine learning solutions for enterprise clients worldwide.', 'https://datavision.com', datetime('now'), datetime('now')),
('CloudScale Systems', 'Cloud infrastructure and DevOps automation platform for modern applications.', 'https://cloudscale.io', datetime('now'), datetime('now')),
('StartupBoost', 'Early-stage startup accelerator helping entrepreneurs build the next big thing.', 'https://startupboost.vc', datetime('now'), datetime('now')),
('NextGen Apps', 'Mobile-first development agency creating innovative apps for iOS and Android.', 'https://nextgen-apps.com', datetime('now'), datetime('now'));

INSERT INTO jobs (company_id, title, description, location, employment_type, salary_range, experience_level, skills_required, created_at, updated_at) VALUES
(1, 'Senior Full Stack Developer', 'Join our team to build scalable web applications using React, Node.js, and PostgreSQL. You will work on our core payment processing platform that handles millions of transactions daily.

Key Responsibilities:
- Develop and maintain React-based frontend applications
- Build robust APIs using Node.js and Express
- Design database schemas and optimize queries
- Collaborate with product and design teams
- Write comprehensive tests and documentation

We offer competitive compensation, flexible working hours, and the opportunity to work with cutting-edge fintech technologies.', 'San Francisco, CA', 'Full-time', '$120,000 - $180,000', 'Senior (5+ years)', 'React,Node.js,PostgreSQL,TypeScript,AWS', datetime('now'), datetime('now')),

(1, 'Frontend Developer', 'Build beautiful and responsive user interfaces for our fintech applications. Work with React, TypeScript, and modern CSS frameworks to create exceptional user experiences.

What you will do:
- Implement pixel-perfect designs using React and CSS
- Optimize applications for maximum speed and scalability
- Collaborate with UX/UI designers and backend developers
- Ensure cross-browser compatibility and responsive design
- Participate in code reviews and maintain coding standards

Perfect for developers who are passionate about creating intuitive financial tools.', 'San Francisco, CA', 'Full-time', '$90,000 - $130,000', 'Mid-level (3-5 years)', 'React,TypeScript,CSS,HTML,JavaScript', datetime('now'), datetime('now')),

(2, 'Machine Learning Engineer', 'Lead the development of AI models that power our data analytics platform. Work with Python, TensorFlow, and cloud technologies to solve complex business problems.

Your role:
- Design and implement machine learning algorithms
- Process and analyze large datasets using Python and SQL
- Deploy models to production using Docker and Kubernetes
- Collaborate with data scientists and software engineers
- Research and implement state-of-the-art ML techniques

Join us in building the future of AI-powered business intelligence.', 'Remote', 'Full-time', '$140,000 - $200,000', 'Senior (5+ years)', 'Python,TensorFlow,PyTorch,SQL,Docker,Kubernetes', datetime('now'), datetime('now')),

(2, 'Data Scientist', 'Transform raw data into actionable insights using statistical analysis and machine learning. Work with our clients to solve real-world business challenges through data.

Responsibilities:
- Analyze complex datasets to identify trends and patterns
- Build predictive models and statistical analyses
- Create data visualizations and reports for stakeholders
- Collaborate with ML engineers to deploy models
- Present findings to clients and internal teams

Ideal for someone with strong analytical skills and business acumen.', 'New York, NY', 'Full-time', '$110,000 - $160,000', 'Mid-level (3-5 years)', 'Python,R,SQL,Tableau,Pandas,Scikit-learn', datetime('now'), datetime('now')),

(3, 'DevOps Engineer', 'Build and maintain scalable cloud infrastructure using AWS, Terraform, and Kubernetes. Help our clients modernize their deployment pipelines and achieve DevOps excellence.

Key duties:
- Design and implement CI/CD pipelines
- Manage cloud infrastructure using Infrastructure as Code
- Monitor application performance and troubleshoot issues
- Automate deployment and scaling processes
- Ensure security and compliance best practices

Great opportunity to work with the latest cloud technologies and make a real impact.', 'Austin, TX', 'Full-time', '$100,000 - $150,000', 'Mid-level (3-5 years)', 'AWS,Kubernetes,Docker,Terraform,Jenkins,Linux', datetime('now'), datetime('now')),

(3, 'Cloud Architect', 'Design enterprise-grade cloud solutions for our Fortune 500 clients. Lead technical discussions and architect systems that scale to millions of users.

What you will do:
- Design scalable and resilient cloud architectures
- Lead technical discussions with clients and stakeholders
- Evaluate and recommend cloud technologies
- Mentor junior engineers and conduct technical reviews
- Ensure solutions meet security and compliance requirements

Perfect for senior technologists who want to shape the future of cloud computing.', 'Seattle, WA', 'Full-time', '$160,000 - $220,000', 'Senior (7+ years)', 'AWS,Azure,GCP,Kubernetes,Microservices,System Design', datetime('now'), datetime('now')),

(4, 'Junior Developer', 'Start your career with us! Work on exciting startup projects while learning from experienced developers. We provide mentorship, training, and growth opportunities.

You will:
- Contribute to web applications using modern frameworks
- Learn best practices for software development
- Participate in daily standups and sprint planning
- Write clean, tested, and documented code
- Grow your skills through pair programming and mentorship

No experience required - just passion for coding and willingness to learn!', 'Remote', 'Full-time', '$60,000 - $80,000', 'Entry-level (0-2 years)', 'JavaScript,React,HTML,CSS,Git', datetime('now'), datetime('now')),

(4, 'Product Manager', 'Drive product strategy and roadmap for our portfolio companies. Work directly with founders to build products that users love and businesses need.

Your responsibilities:
- Define product vision and strategy
- Conduct user research and market analysis
- Write detailed product requirements and user stories
- Collaborate with engineering and design teams
- Track product metrics and iterate based on feedback

Ideal for someone who wants to make a direct impact on startup success.', 'San Francisco, CA', 'Full-time', '$130,000 - $180,000', 'Mid-level (4-6 years)', 'Product Management,Analytics,User Research,Agile,SQL', datetime('now'), datetime('now')),

(5, 'Mobile Developer (iOS)', 'Build amazing iOS applications that reach millions of users worldwide. Work with the latest iOS technologies and contribute to our clients'' mobile success.

What you will do:
- Develop native iOS apps using Swift and SwiftUI
- Implement complex UI animations and interactions
- Integrate with REST APIs and third-party services
- Optimize app performance and user experience
- Collaborate with designers and backend developers

Join us in creating the next generation of mobile experiences!', 'Los Angeles, CA', 'Full-time', '$95,000 - $140,000', 'Mid-level (3-5 years)', 'Swift,SwiftUI,iOS,Xcode,REST APIs,Core Data', datetime('now'), datetime('now')),

(5, 'UI/UX Designer', 'Design intuitive and beautiful user interfaces for mobile and web applications. Work closely with clients to understand their needs and create designs that drive business results.

Your role includes:
- Create wireframes, prototypes, and high-fidelity designs
- Conduct user research and usability testing
- Design user flows and information architecture
- Collaborate with developers to ensure design implementation
- Present design concepts to clients and stakeholders

Perfect for designers who want to work on diverse projects and see their designs come to life.', 'Los Angeles, CA', 'Full-time', '$80,000 - $120,000', 'Mid-level (3-5 years)', 'Figma,Sketch,Adobe Creative Suite,Prototyping,User Research', datetime('now'), datetime('now'));
