import z from "zod";

export const CompanySchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  website_url: z.string().nullable(),
  logo_url: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const JobSchema = z.object({
  id: z.number(),
  company_id: z.number(),
  title: z.string(),
  description: z.string(),
  location: z.string().nullable(),
  employment_type: z.string(),
  salary_range: z.string().nullable(),
  experience_level: z.string().nullable(),
  skills_required: z.string().nullable(),
  is_active: z.number().int(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const JobWithCompanySchema = JobSchema.extend({
  company: CompanySchema,
});

export const UserProfileSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  full_name: z.string().nullable(),
  bio: z.string().nullable(),
  location: z.string().nullable(),
  skills: z.string().nullable(),
  github_username: z.string().nullable(),
  portfolio_url: z.string().nullable(),
  resume_url: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const ApplicationSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  job_id: z.number(),
  status: z.string(),
  cover_letter: z.string().nullable(),
  github_repo_url: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const ApplicationWithJobSchema = ApplicationSchema.extend({
  job: JobWithCompanySchema,
});

export const CreateApplicationSchema = z.object({
  job_id: z.number(),
  cover_letter: z.string().optional(),
  github_repo_url: z.string().url().optional(),
});

export const UpdateProfileSchema = z.object({
  full_name: z.string().optional(),
  bio: z.string().optional(),
  location: z.string().optional(),
  skills: z.string().optional(),
  github_username: z.string().optional(),
  portfolio_url: z.string().url().optional(),
  resume_url: z.string().url().optional(),
});

export type Company = z.infer<typeof CompanySchema>;
export type Job = z.infer<typeof JobSchema>;
export type JobWithCompany = z.infer<typeof JobWithCompanySchema>;
export type UserProfile = z.infer<typeof UserProfileSchema>;
export type Application = z.infer<typeof ApplicationSchema>;
export type ApplicationWithJob = z.infer<typeof ApplicationWithJobSchema>;
export type CreateApplication = z.infer<typeof CreateApplicationSchema>;
export type UpdateProfile = z.infer<typeof UpdateProfileSchema>;
