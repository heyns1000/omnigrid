import { Hono } from "hono";
import { cors } from "hono/cors";
import { 
  getOAuthRedirectUrl, 
  exchangeCodeForSessionToken, 
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";
import { zValidator } from "@hono/zod-validator";
import { CreateApplicationSchema, UpdateProfileSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use("*", cors({
  origin: ["http://localhost:5173"],
  credentials: true,
}));

// Auth routes
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Jobs routes
app.get('/api/jobs', async (c) => {
  const { results } = await c.env.DB.prepare(`
    SELECT j.*, c.name as company_name, c.description as company_description, 
           c.website_url as company_website_url, c.logo_url as company_logo_url
    FROM jobs j 
    JOIN companies c ON j.company_id = c.id 
    WHERE j.is_active = 1 
    ORDER BY j.created_at DESC
  `).all();

  const jobs = results.map((row: any) => ({
    id: row.id,
    company_id: row.company_id,
    title: row.title,
    description: row.description,
    location: row.location,
    employment_type: row.employment_type,
    salary_range: row.salary_range,
    experience_level: row.experience_level,
    skills_required: row.skills_required,
    is_active: row.is_active,
    created_at: row.created_at,
    updated_at: row.updated_at,
    company: {
      id: row.company_id,
      name: row.company_name,
      description: row.company_description,
      website_url: row.company_website_url,
      logo_url: row.company_logo_url,
      created_at: row.created_at,
      updated_at: row.updated_at,
    }
  }));

  return c.json(jobs);
});

app.get('/api/jobs/:id', async (c) => {
  const id = parseInt(c.req.param('id'));
  
  const result = await c.env.DB.prepare(`
    SELECT j.*, c.name as company_name, c.description as company_description, 
           c.website_url as company_website_url, c.logo_url as company_logo_url
    FROM jobs j 
    JOIN companies c ON j.company_id = c.id 
    WHERE j.id = ? AND j.is_active = 1
  `).bind(id).first();

  if (!result) {
    return c.json({ error: 'Job not found' }, 404);
  }

  const job = {
    id: result.id,
    company_id: result.company_id,
    title: result.title,
    description: result.description,
    location: result.location,
    employment_type: result.employment_type,
    salary_range: result.salary_range,
    experience_level: result.experience_level,
    skills_required: result.skills_required,
    is_active: result.is_active,
    created_at: result.created_at,
    updated_at: result.updated_at,
    company: {
      id: result.company_id,
      name: result.company_name,
      description: result.company_description,
      website_url: result.company_website_url,
      logo_url: result.company_logo_url,
      created_at: result.created_at,
      updated_at: result.updated_at,
    }
  };

  return c.json(job);
});

// User profile routes
app.get('/api/profile', authMiddleware, async (c) => {
  const user = c.get('user')!;
  
  const profile = await c.env.DB.prepare(`
    SELECT * FROM user_profiles WHERE user_id = ?
  `).bind(user!.id).first();

  if (!profile) {
    // Create default profile
    await c.env.DB.prepare(`
      INSERT INTO user_profiles (user_id, full_name, created_at, updated_at) 
      VALUES (?, ?, datetime('now'), datetime('now'))
    `).bind(user!.id, user!.google_user_data.name || '').run();

    const newProfile = await c.env.DB.prepare(`
      SELECT * FROM user_profiles WHERE user_id = ?
    `).bind(user!.id).first();

    return c.json(newProfile);
  }

  return c.json(profile);
});

app.put('/api/profile', authMiddleware, zValidator('json', UpdateProfileSchema), async (c) => {
  const user = c.get('user')!;
  const profileData = c.req.valid('json');

  const updateFields = Object.keys(profileData)
    .map(key => `${key} = ?`)
    .join(', ');
  
  const values = [...Object.values(profileData), user!.id];

  await c.env.DB.prepare(`
    UPDATE user_profiles 
    SET ${updateFields}, updated_at = datetime('now') 
    WHERE user_id = ?
  `).bind(...values).run();

  const updatedProfile = await c.env.DB.prepare(`
    SELECT * FROM user_profiles WHERE user_id = ?
  `).bind(user!.id).first();

  return c.json(updatedProfile);
});

// Applications routes
app.get('/api/applications', authMiddleware, async (c) => {
  const user = c.get('user')!;
  
  const { results } = await c.env.DB.prepare(`
    SELECT a.*, j.title as job_title, j.description as job_description,
           j.location as job_location, j.employment_type as job_employment_type,
           j.salary_range as job_salary_range, j.experience_level as job_experience_level,
           c.name as company_name, c.logo_url as company_logo_url
    FROM applications a
    JOIN jobs j ON a.job_id = j.id
    JOIN companies c ON j.company_id = c.id
    WHERE a.user_id = ?
    ORDER BY a.created_at DESC
  `).bind(user!.id).all();

  const applications = results.map((row: any) => ({
    id: row.id,
    user_id: row.user_id,
    job_id: row.job_id,
    status: row.status,
    cover_letter: row.cover_letter,
    github_repo_url: row.github_repo_url,
    created_at: row.created_at,
    updated_at: row.updated_at,
    job: {
      id: row.job_id,
      title: row.job_title,
      description: row.job_description,
      location: row.job_location,
      employment_type: row.job_employment_type,
      salary_range: row.job_salary_range,
      experience_level: row.job_experience_level,
      company: {
        name: row.company_name,
        logo_url: row.company_logo_url,
      }
    }
  }));

  return c.json(applications);
});

app.post('/api/applications', authMiddleware, zValidator('json', CreateApplicationSchema), async (c) => {
  const user = c.get('user')!;
  const applicationData = c.req.valid('json');

  // Check if user already applied to this job
  const existing = await c.env.DB.prepare(`
    SELECT id FROM applications WHERE user_id = ? AND job_id = ?
  `).bind(user!.id, applicationData.job_id).first();

  if (existing) {
    return c.json({ error: 'You have already applied to this job' }, 400);
  }

  const result = await c.env.DB.prepare(`
    INSERT INTO applications (user_id, job_id, cover_letter, github_repo_url, created_at, updated_at)
    VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
  `).bind(
    user!.id,
    applicationData.job_id,
    applicationData.cover_letter || null,
    applicationData.github_repo_url || null
  ).run();

  const application = await c.env.DB.prepare(`
    SELECT * FROM applications WHERE id = ?
  `).bind(result.meta.last_row_id).first();

  return c.json(application, 201);
});

export default app;
