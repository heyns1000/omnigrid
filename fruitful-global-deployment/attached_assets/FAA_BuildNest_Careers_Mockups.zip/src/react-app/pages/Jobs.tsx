import { useEffect, useState } from "react";
import { Link } from "react-router";
import { MapPin, Building, Clock, DollarSign } from "lucide-react";
import type { JobWithCompany } from "@/shared/types";

export default function Jobs() {
  const [jobs, setJobs] = useState<JobWithCompany[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await fetch('/api/jobs');
        if (!response.ok) {
          throw new Error('Failed to fetch jobs');
        }
        const data = await response.json();
        setJobs(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading jobs...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-400 mb-4">Error: {error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="bg-emerald-600 hover:bg-emerald-700 px-4 py-2 rounded-md transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section with whozaFriday Image */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://mocha-cdn.com/0199914d-657b-7188-b54e-12b480d8d783/Fruitful_Global_Brand_whozaFriday.png"
            alt="Fruitful Global Brand - whozaFriday Music Culture"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30"></div>
        </div>
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl lg:text-6xl font-bold text-emerald-400 mb-6">
            ✨ Open Roles at FAA.ZONE™
          </h1>
          <p className="text-xl text-white font-light">
            Join the vibrant pulse of innovation at <em className="text-emerald-400">FAA Systems™</em>. 
            Discover opportunities to build the future of enterprise technology through the 
            <em className="text-blue-400"> Omni Grid™</em> ecosystem.
          </p>
        </div>
      </section>

      {/* Jobs Grid Section */}
      <section className="py-16 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {jobs.length === 0 ? (
            <div className="text-center py-20">
              <Building className="w-20 h-20 text-gray-600 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-gray-400 mb-4">No jobs available</h3>
              <p className="text-gray-500 text-lg">Check back soon for new opportunities!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {jobs.map((job) => (
                <Link
                  key={job.id}
                  to={`/jobs/${job.id}`}
                  className="bg-gradient-to-br from-gray-800/95 to-gray-900/95 rounded-2xl border border-gray-700 hover:border-emerald-400/60 p-8 transition-all duration-300 transform hover:scale-[1.02] group backdrop-blur-sm shadow-xl hover:shadow-emerald-500/20"
                >
                  <div className="flex items-start justify-between mb-6">
                    <div className="flex items-center space-x-4">
                      {job.company.logo_url ? (
                        <img
                          src={job.company.logo_url}
                          alt={job.company.name}
                          className="w-14 h-14 rounded-xl object-cover"
                        />
                      ) : (
                        <div className="w-14 h-14 bg-gray-700 rounded-xl flex items-center justify-center">
                          <Building className="w-7 h-7 text-gray-400" />
                        </div>
                      )}
                      <div>
                        <h2 className="text-xl font-semibold text-white group-hover:text-emerald-400 transition-colors">
                          {job.title}
                        </h2>
                        <p className="text-gray-400 text-lg">{job.company.name}</p>
                      </div>
                    </div>
                    <span className="bg-emerald-600/30 text-emerald-400 px-4 py-2 rounded-full text-sm font-medium border border-emerald-500/30">
                      {job.employment_type}
                    </span>
                  </div>

                  <p className="text-gray-300 mb-6 line-clamp-3 text-lg">
                    {job.description}
                  </p>

                  <div className="flex flex-wrap items-center gap-6 text-gray-400 mb-6">
                    {job.location && (
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-5 h-5" />
                        <span>{job.location}</span>
                      </div>
                    )}
                    {job.experience_level && (
                      <div className="flex items-center space-x-2">
                        <Clock className="w-5 h-5" />
                        <span>{job.experience_level}</span>
                      </div>
                    )}
                    {job.salary_range && (
                      <div className="flex items-center space-x-2">
                        <DollarSign className="w-5 h-5" />
                        <span>{job.salary_range}</span>
                      </div>
                    )}
                  </div>

                  {job.skills_required && (
                    <div>
                      <div className="flex flex-wrap gap-2">
                        {job.skills_required.split(',').slice(0, 4).map((skill, index) => (
                          <span
                            key={index}
                            className="bg-gray-700/80 text-gray-300 px-3 py-1 rounded-lg text-sm border border-gray-600"
                          >
                            {skill.trim()}
                          </span>
                        ))}
                        {job.skills_required.split(',').length > 4 && (
                          <span className="text-gray-500 text-sm flex items-center">
                            +{job.skills_required.split(',').length - 4} more
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
