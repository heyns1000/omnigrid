import { useEffect, useState } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { Navigate, Link } from "react-router";
import { FileText, Clock, CheckCircle, XCircle, ExternalLink, Building } from "lucide-react";
import type { ApplicationWithJob } from "@/shared/types";

export default function Applications() {
  const { user, isPending } = useAuth();
  const [applications, setApplications] = useState<ApplicationWithJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const response = await fetch('/api/applications', {
          credentials: 'include',
        });
        if (!response.ok) {
          throw new Error('Failed to fetch applications');
        }
        const data = await response.json();
        setApplications(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchApplications();
    }
  }, [user]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-400" />;
      case 'accepted':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-400" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-600/30 text-yellow-400 border-yellow-500/40';
      case 'accepted':
        return 'bg-green-600/30 text-green-400 border-green-500/40';
      case 'rejected':
        return 'bg-red-600/30 text-red-400 border-red-500/40';
      default:
        return 'bg-gray-600/30 text-gray-400 border-gray-500/40';
    }
  };

  if (isPending || loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading applications...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/" replace />;
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-400 mb-4">Error: {error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-md transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section with Megaflight Image */}
      <section className="relative h-80 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://mocha-cdn.com/0199914d-657b-7188-b54e-12b480d8d783/Fruitful_Global_Brand_Megaflight.png"
            alt="Fruitful Global Brand - Applications Dashboard"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30"></div>
        </div>
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4">My Applications</h1>
          <p className="text-xl text-gray-200 font-light">
            Track the status of your job applications and manage your career opportunities 
            at <em className="text-emerald-400">FAA.ZONE™</em>.
          </p>
        </div>
      </section>

      {/* Applications Section */}
      <section className="py-16 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {applications.length === 0 ? (
            <div className="text-center py-20">
              <FileText className="w-24 h-24 text-gray-600 mx-auto mb-8" />
              <h3 className="text-2xl font-semibold text-gray-400 mb-4">No applications yet</h3>
              <p className="text-gray-500 mb-8 text-lg">
                Start applying to jobs to see your applications here.
              </p>
              <Link
                to="/jobs"
                className="bg-blue-600 hover:bg-blue-700 px-8 py-4 rounded-xl font-medium transition-colors text-lg"
              >
                Browse Jobs
              </Link>
            </div>
          ) : (
            <div className="space-y-8">
              {applications.map((application) => (
                <div
                  key={application.id}
                  className="bg-gradient-to-br from-gray-800/95 to-gray-900/95 rounded-2xl border border-gray-700 p-8 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  <div className="flex items-start justify-between mb-6">
                    <div className="flex items-start space-x-6">
                      {application.job.company.logo_url ? (
                        <img
                          src={application.job.company.logo_url}
                          alt={application.job.company.name}
                          className="w-16 h-16 rounded-xl object-cover"
                        />
                      ) : (
                        <div className="w-16 h-16 bg-gray-700 rounded-xl flex items-center justify-center">
                          <Building className="w-8 h-8 text-gray-400" />
                        </div>
                      )}
                      <div>
                        <h3 className="text-2xl font-semibold text-white mb-2">
                          {application.job.title}
                        </h3>
                        <p className="text-gray-400 text-lg">{application.job.company.name}</p>
                        <p className="text-gray-500">
                          Applied on {new Date(application.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-6">
                      <div className={`flex items-center space-x-3 px-4 py-2 rounded-xl border ${getStatusColor(application.status)}`}>
                        {getStatusIcon(application.status)}
                        <span className="font-medium capitalize text-lg">{application.status}</span>
                      </div>
                      <Link
                        to={`/jobs/${application.job_id}`}
                        className="text-blue-400 hover:text-blue-300 transition-colors"
                      >
                        <ExternalLink className="w-6 h-6" />
                      </Link>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    {application.job.location && (
                      <div>
                        <span className="text-gray-500 font-medium">Location:</span>
                        <span className="text-gray-300 ml-3 text-lg">{application.job.location}</span>
                      </div>
                    )}
                    {application.job.employment_type && (
                      <div>
                        <span className="text-gray-500 font-medium">Type:</span>
                        <span className="text-gray-300 ml-3 text-lg">{application.job.employment_type}</span>
                      </div>
                    )}
                    {application.job.salary_range && (
                      <div>
                        <span className="text-gray-500 font-medium">Salary:</span>
                        <span className="text-gray-300 ml-3 text-lg">{application.job.salary_range}</span>
                      </div>
                    )}
                    {application.job.experience_level && (
                      <div>
                        <span className="text-gray-500 font-medium">Experience:</span>
                        <span className="text-gray-300 ml-3 text-lg">{application.job.experience_level}</span>
                      </div>
                    )}
                  </div>

                  {application.cover_letter && (
                    <div className="mb-6 p-6 bg-gray-700/50 rounded-xl">
                      <h4 className="font-medium text-gray-300 mb-3 text-lg">Cover Letter</h4>
                      <p className="text-gray-400 whitespace-pre-wrap leading-relaxed">
                        {application.cover_letter}
                      </p>
                    </div>
                  )}

                  {application.github_repo_url && (
                    <div>
                      <a
                        href={application.github_repo_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-3 text-blue-400 hover:text-blue-300 transition-colors text-lg"
                      >
                        <ExternalLink className="w-5 h-5" />
                        <span>View GitHub Repository</span>
                      </a>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
