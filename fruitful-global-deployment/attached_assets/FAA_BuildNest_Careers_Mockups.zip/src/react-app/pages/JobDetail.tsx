import { useEffect, useState } from "react";
import { useParams, Link } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { MapPin, Building, Clock, DollarSign, ExternalLink, Github, Send } from "lucide-react";
import type { JobWithCompany } from "@/shared/types";

export default function JobDetail() {
  const { id } = useParams<{ id: string }>();
  const { user, redirectToLogin } = useAuth();
  const [job, setJob] = useState<JobWithCompany | null>(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [applied, setApplied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [coverLetter, setCoverLetter] = useState("");
  const [githubRepo, setGithubRepo] = useState("");

  useEffect(() => {
    const fetchJob = async () => {
      try {
        const response = await fetch(`/api/jobs/${id}`);
        if (!response.ok) {
          throw new Error('Job not found');
        }
        const data = await response.json();
        setJob(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchJob();
    }
  }, [id]);

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !job) return;

    setApplying(true);
    try {
      const response = await fetch('/api/applications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          job_id: job.id,
          cover_letter: coverLetter || undefined,
          github_repo_url: githubRepo || undefined,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit application');
      }

      setApplied(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setApplying(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading job details...</p>
        </div>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-400 mb-4">Error: {error || 'Job not found'}</p>
          <Link 
            to="/jobs"
            className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-md transition-colors"
          >
            Back to Jobs
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section with Featured Image */}
      <section className="relative h-80 flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://mocha-cdn.com/0199914d-657b-7188-b54e-12b480d8d783/Fruitful_Global_Brand_whozaFriday.png"
            alt="Fruitful Global Brand - Career Opportunity"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent"></div>
        </div>
        <div className="relative z-10 w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <Link 
            to="/jobs"
            className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors mb-6 text-lg"
          >
            ← Back to Jobs
          </Link>
          <div className="flex items-center space-x-6">
            {job.company.logo_url ? (
              <img
                src={job.company.logo_url}
                alt={job.company.name}
                className="w-20 h-20 rounded-xl object-cover border-2 border-white/20"
              />
            ) : (
              <div className="w-20 h-20 bg-gray-700/80 rounded-xl flex items-center justify-center border-2 border-white/20">
                <Building className="w-10 h-10 text-gray-400" />
              </div>
            )}
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">{job.title}</h1>
              <div className="flex items-center space-x-3">
                <span className="text-2xl text-gray-200">{job.company.name}</span>
                {job.company.website_url && (
                  <a
                    href={job.company.website_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 hover:text-blue-300 transition-colors"
                  >
                    <ExternalLink className="w-5 h-5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Job Details Section */}
      <section className="py-12 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-gray-800/95 to-gray-900/95 rounded-2xl border border-gray-700 p-10 mb-10 backdrop-blur-sm shadow-2xl">
            <div className="flex items-center justify-between mb-8">
              <div className="flex flex-wrap items-center gap-8 text-gray-300">
                {job.location && (
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-6 h-6 text-emerald-400" />
                    <span className="text-lg">{job.location}</span>
                  </div>
                )}
                {job.experience_level && (
                  <div className="flex items-center space-x-2">
                    <Clock className="w-6 h-6 text-blue-400" />
                    <span className="text-lg">{job.experience_level}</span>
                  </div>
                )}
                {job.salary_range && (
                  <div className="flex items-center space-x-2">
                    <DollarSign className="w-6 h-6 text-purple-400" />
                    <span className="text-lg">{job.salary_range}</span>
                  </div>
                )}
              </div>
              <span className="bg-blue-600/30 text-blue-400 px-6 py-3 rounded-xl text-lg font-medium border border-blue-500/30">
                {job.employment_type}
              </span>
            </div>

            {job.skills_required && (
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-white mb-4">Required Skills</h3>
                <div className="flex flex-wrap gap-3">
                  {job.skills_required.split(',').map((skill, index) => (
                    <span
                      key={index}
                      className="bg-gray-700/80 text-gray-300 px-4 py-2 rounded-xl text-sm border border-gray-600"
                    >
                      {skill.trim()}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="mb-10">
              <h3 className="text-xl font-semibold text-white mb-4">Job Description</h3>
              <div className="prose prose-invert max-w-none">
                <p className="text-gray-300 whitespace-pre-wrap text-lg leading-relaxed">{job.description}</p>
              </div>
            </div>

            {job.company.description && (
              <div>
                <h3 className="text-xl font-semibold text-white mb-4">About {job.company.name}</h3>
                <p className="text-gray-300 text-lg leading-relaxed">{job.company.description}</p>
              </div>
            )}
          </div>

          {/* Application Form */}
          {user ? (
            applied ? (
              <div className="bg-gradient-to-br from-green-900/60 to-green-800/60 border-2 border-green-500/40 rounded-2xl p-10 text-center backdrop-blur-sm shadow-2xl">
                <div className="w-20 h-20 bg-green-500/30 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Send className="w-10 h-10 text-green-400" />
                </div>
                <h3 className="text-2xl font-semibold text-white mb-4">Application Submitted!</h3>
                <p className="text-gray-200 mb-8 text-lg">
                  Your application has been sent to {job.company.name}. You can track the status in your applications dashboard.
                </p>
                <Link
                  to="/applications"
                  className="bg-green-600 hover:bg-green-700 px-8 py-3 rounded-xl transition-colors text-lg font-medium"
                >
                  View My Applications
                </Link>
              </div>
            ) : (
              <div className="bg-gradient-to-br from-gray-800/95 to-gray-900/95 rounded-2xl border border-gray-700 p-10 backdrop-blur-sm shadow-2xl">
                <h3 className="text-2xl font-semibold text-white mb-8">Apply for this Position</h3>
                <form onSubmit={handleApply} className="space-y-8">
                  <div>
                    <label htmlFor="coverLetter" className="block text-lg font-medium text-gray-300 mb-3">
                      Cover Letter (Optional)
                    </label>
                    <textarea
                      id="coverLetter"
                      value={coverLetter}
                      onChange={(e) => setCoverLetter(e.target.value)}
                      rows={6}
                      className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                      placeholder="Tell the company why you're interested in this role..."
                    />
                  </div>

                  <div>
                    <label htmlFor="githubRepo" className="block text-lg font-medium text-gray-300 mb-3">
                      <Github className="w-5 h-5 inline mr-2" />
                      Relevant GitHub Repository (Optional)
                    </label>
                    <input
                      type="url"
                      id="githubRepo"
                      value={githubRepo}
                      onChange={(e) => setGithubRepo(e.target.value)}
                      className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                      placeholder="https://github.com/username/repository"
                    />
                    <p className="text-gray-500 mt-2">
                      Share a repository that best demonstrates your skills for this role
                    </p>
                  </div>

                  {error && (
                    <div className="bg-red-900/40 border border-red-500/40 rounded-xl p-6">
                      <p className="text-red-400 text-lg">{error}</p>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={applying}
                    className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed px-8 py-4 rounded-xl font-medium transition-colors flex items-center justify-center space-x-3 text-lg"
                  >
                    {applying ? (
                      <>
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                        <span>Submitting...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5" />
                        <span>Submit Application</span>
                      </>
                    )}
                  </button>
                </form>
              </div>
            )
          ) : (
            <div className="bg-gradient-to-br from-gray-800/95 to-gray-900/95 rounded-2xl border border-gray-700 p-10 text-center backdrop-blur-sm shadow-2xl">
              <h3 className="text-2xl font-semibold text-white mb-6">Ready to Apply?</h3>
              <p className="text-gray-300 mb-8 text-lg">
                Sign in to submit your application and connect your GitHub profile.
              </p>
              <button
                onClick={redirectToLogin}
                className="bg-blue-600 hover:bg-blue-700 px-8 py-4 rounded-xl font-medium transition-colors text-lg"
              >
                Sign In to Apply
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
