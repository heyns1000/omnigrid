import { useEffect, useState } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { Navigate } from "react-router";
import { User, Github, MapPin, Save, ExternalLink } from "lucide-react";
import type { UserProfile } from "@/shared/types";

export default function Profile() {
  const { user, isPending } = useAuth();
  const [, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    full_name: "",
    bio: "",
    location: "",
    skills: "",
    github_username: "",
    portfolio_url: "",
    resume_url: "",
  });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch('/api/profile', {
          credentials: 'include',
        });
        if (!response.ok) {
          throw new Error('Failed to fetch profile');
        }
        const data = await response.json();
        setProfile(data);
        setFormData({
          full_name: data.full_name || "",
          bio: data.bio || "",
          location: data.location || "",
          skills: data.skills || "",
          github_username: data.github_username || "",
          portfolio_url: data.portfolio_url || "",
          resume_url: data.resume_url || "",
        });
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchProfile();
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(false);

    try {
      const response = await fetch('/api/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to update profile');
      }

      const updatedProfile = await response.json();
      setProfile(updatedProfile);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setSaving(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  if (isPending || loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section with Main Brand Image */}
      <section className="relative h-80 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://mocha-cdn.com/0199914d-657b-7188-b54e-12b480d8d783/Fruitful_Global_Brand.png"
            alt="Fruitful Global Brand - Profile Management"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30"></div>
        </div>
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4">Profile Settings</h1>
          <p className="text-xl text-gray-200 font-light">
            Manage your profile information and showcase your GitHub repositories to potential employers 
            at <em className="text-emerald-400">FAA.ZONE™</em>.
          </p>
        </div>
      </section>

      {/* Profile Management Section */}
      <section className="py-16 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Profile Summary */}
            <div className="lg:col-span-1">
              <div className="bg-gradient-to-br from-gray-800/95 to-gray-900/95 rounded-2xl border border-gray-700 p-8 sticky top-24 backdrop-blur-sm shadow-xl">
                <div className="text-center">
                  {user.google_user_data.picture ? (
                    <img
                      src={user.google_user_data.picture}
                      alt="Profile"
                      className="w-32 h-32 rounded-full mx-auto mb-6 border-4 border-gray-600"
                    />
                  ) : (
                    <div className="w-32 h-32 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-6 border-4 border-gray-600">
                      <User className="w-16 h-16 text-gray-400" />
                    </div>
                  )}
                  <h2 className="text-2xl font-semibold text-white mb-3">
                    {formData.full_name || user.google_user_data.name || 'User'}
                  </h2>
                  <p className="text-gray-400 mb-6 text-lg">{user.email}</p>
                  
                  {formData.github_username && (
                    <a
                      href={`https://github.com/${formData.github_username}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors mb-4 text-lg"
                    >
                      <Github className="w-5 h-5" />
                      <span>@{formData.github_username}</span>
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                  
                  {formData.location && (
                    <div className="flex items-center justify-center space-x-2 text-gray-400">
                      <MapPin className="w-5 h-5" />
                      <span className="text-lg">{formData.location}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Profile Form */}
            <div className="lg:col-span-2">
              <div className="bg-gradient-to-br from-gray-800/95 to-gray-900/95 rounded-2xl border border-gray-700 p-10 backdrop-blur-sm shadow-xl">
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <label htmlFor="full_name" className="block text-lg font-medium text-gray-300 mb-3">
                        Full Name
                      </label>
                      <input
                        type="text"
                        id="full_name"
                        name="full_name"
                        value={formData.full_name}
                        onChange={handleInputChange}
                        className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                        placeholder="Enter your full name"
                      />
                    </div>

                    <div>
                      <label htmlFor="location" className="block text-lg font-medium text-gray-300 mb-3">
                        <MapPin className="w-5 h-5 inline mr-2" />
                        Location
                      </label>
                      <input
                        type="text"
                        id="location"
                        name="location"
                        value={formData.location}
                        onChange={handleInputChange}
                        className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                        placeholder="City, Country"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="bio" className="block text-lg font-medium text-gray-300 mb-3">
                      Bio
                    </label>
                    <textarea
                      id="bio"
                      name="bio"
                      value={formData.bio}
                      onChange={handleInputChange}
                      rows={5}
                      className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                      placeholder="Tell us about yourself and your experience..."
                    />
                  </div>

                  <div>
                    <label htmlFor="skills" className="block text-lg font-medium text-gray-300 mb-3">
                      Skills
                    </label>
                    <input
                      type="text"
                      id="skills"
                      name="skills"
                      value={formData.skills}
                      onChange={handleInputChange}
                      className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                      placeholder="JavaScript, Python, React, Node.js (comma-separated)"
                    />
                    <p className="text-gray-500 mt-2">
                      List your technical skills separated by commas
                    </p>
                  </div>

                  <div>
                    <label htmlFor="github_username" className="block text-lg font-medium text-gray-300 mb-3">
                      <Github className="w-5 h-5 inline mr-2" />
                      GitHub Username
                    </label>
                    <input
                      type="text"
                      id="github_username"
                      name="github_username"
                      value={formData.github_username}
                      onChange={handleInputChange}
                      className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                      placeholder="your-github-username"
                    />
                    <p className="text-gray-500 mt-2">
                      Your GitHub username (without @)
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <label htmlFor="portfolio_url" className="block text-lg font-medium text-gray-300 mb-3">
                        Portfolio URL
                      </label>
                      <input
                        type="url"
                        id="portfolio_url"
                        name="portfolio_url"
                        value={formData.portfolio_url}
                        onChange={handleInputChange}
                        className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                        placeholder="https://yourportfolio.com"
                      />
                    </div>

                    <div>
                      <label htmlFor="resume_url" className="block text-lg font-medium text-gray-300 mb-3">
                        Resume URL
                      </label>
                      <input
                        type="url"
                        id="resume_url"
                        name="resume_url"
                        value={formData.resume_url}
                        onChange={handleInputChange}
                        className="w-full bg-gray-700/80 border border-gray-600 rounded-xl px-5 py-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                        placeholder="https://link-to-your-resume.pdf"
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="bg-red-900/40 border border-red-500/40 rounded-xl p-6">
                      <p className="text-red-400 text-lg">{error}</p>
                    </div>
                  )}

                  {success && (
                    <div className="bg-green-900/40 border border-green-500/40 rounded-xl p-6">
                      <p className="text-green-400 text-lg">Profile updated successfully!</p>
                    </div>
                  )}

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={saving}
                      className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed px-8 py-4 rounded-xl font-medium transition-colors flex items-center space-x-3 text-lg"
                    >
                      {saving ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                          <span>Saving...</span>
                        </>
                      ) : (
                        <>
                          <Save className="w-5 h-5" />
                          <span>Save Profile</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
