import { useEffect, useRef } from "react";
import { Link } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Building2, Grid3X3, ArrowRight, Code, Database } from "lucide-react";

export default function Home() {
  const { user } = useAuth();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // FAA.ZONE™ style pulse animation with vibrant colors
    const lines: any[] = [];
    const numLines = 400;
    const pulseDuration = 3000;
    const pulseAmplitude = 0.8;

    for (let i = 0; i < numLines; i++) {
      lines.push({
        offset: Math.random() * Math.PI * 2,
        amplitude: Math.random() * 0.4 + 0.1,
        frequency: Math.random() * 0.08 + 0.005,
        color: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.random() * 0.7 + 0.3})`,
        thickness: Math.random() * 1.5 + 0.5
      });
    }

    let startTime = Date.now();

    const animate = () => {
      requestAnimationFrame(animate);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const currentTime = Date.now();
      const elapsedTime = currentTime - startTime;
      const pulseProgress = (elapsedTime % pulseDuration) / pulseDuration;
      const pulseEffect = Math.sin(pulseProgress * Math.PI * 2) * pulseAmplitude;

      for (let i = 0; i < numLines; i++) {
        const line = lines[i];
        ctx.beginPath();
        ctx.strokeStyle = line.color;
        ctx.lineWidth = line.thickness;
        ctx.lineCap = 'round';

        for (let x = 0; x <= canvas.width; x += 5) {
          const y = canvas.height / 2 +
                    Math.sin(x * line.frequency + line.offset + pulseEffect * 5) * (line.amplitude * canvas.height / 2) +
                    Math.sin(pulseProgress * Math.PI * 2 + i * 0.1) * (canvas.height / 8);

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section with Prominent Brand Image */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://mocha-cdn.com/0199914d-657b-7188-b54e-12b480d8d783/Fruitful_Global_Brand.png"
            alt="Fruitful Global Brand - FAA.ZONE Innovation"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent"></div>
        </div>
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full opacity-30"
        />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center items-center space-x-3 mb-8">
            <Grid3X3 className="w-16 h-16 text-blue-400" />
            <Building2 className="w-14 h-14 text-emerald-400" />
          </div>
          <h1 className="text-5xl lg:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
              FAA.ZONE™
            </span>
            <span className="text-white text-4xl lg:text-5xl block mt-4">
              / BuildNest™ Careers
            </span>
          </h1>
          <p className="text-2xl lg:text-3xl text-white max-w-5xl mx-auto mb-12 font-light">
            ✨ Experience the vibrant pulse of innovation at <em className="text-emerald-400">FAA Systems™</em>. 
            Connect with cutting-edge opportunities and join the ecosystem that's revolutionizing digital infrastructure 
            through the <em className="text-blue-400">Omni Grid™</em>.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link
              to="/jobs"
              className="inline-flex items-center px-10 py-5 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-xl font-medium transition-all duration-300 transform hover:scale-105 shadow-2xl hover:shadow-emerald-500/25"
            >
              Explore Open Roles
              <ArrowRight className="ml-3 w-6 h-6" />
            </Link>
            {!user && (
              <Link
                to="/jobs"
                className="inline-flex items-center px-10 py-5 border-2 border-white/30 hover:border-emerald-400 bg-white/10 backdrop-blur-sm rounded-xl text-xl font-medium transition-all duration-300 hover:bg-emerald-900/20"
              >
                Learn About Our Culture
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* Innovation Showcase with Megaflight Image */}
      <section className="relative py-24">
        <div className="absolute inset-0">
          <img 
            src="https://mocha-cdn.com/0199914d-657b-7188-b54e-12b480d8d783/Fruitful_Global_Brand_Megaflight.png"
            alt="Fruitful Global Brand - Megaflight Technology"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/70 to-black/90"></div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
              📈 The Rhythmic Pulse of Our Daily Innovations
            </h2>
            <p className="text-xl text-gray-200 max-w-4xl mx-auto font-light">
              Join the team that's building tomorrow's digital ecosystem. Every day brings a <em className="text-emerald-400">breath of fresh air</em> 
              to the world of enterprise technology at our headquarters in Pretoria.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="bg-gradient-to-br from-gray-800/90 to-gray-900/90 p-10 rounded-2xl border border-gray-600 hover:border-emerald-400/50 transition-all duration-300 transform hover:scale-105 backdrop-blur-md">
              <div className="bg-emerald-600/30 w-16 h-16 rounded-xl flex items-center justify-center mb-8">
                <Grid3X3 className="w-8 h-8 text-emerald-400" />
              </div>
              <h3 className="text-2xl font-semibold text-white mb-6">Omni Grid™ Integration</h3>
              <p className="text-gray-300 text-lg">
                Work with cutting-edge distributed systems that power enterprise-grade digital ecosystems. 
                Shape the future of scalable infrastructure.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-800/90 to-gray-900/90 p-10 rounded-2xl border border-gray-600 hover:border-blue-400/50 transition-all duration-300 transform hover:scale-105 backdrop-blur-md">
              <div className="bg-blue-600/30 w-16 h-16 rounded-xl flex items-center justify-center mb-8">
                <Code className="w-8 h-8 text-blue-400" />
              </div>
              <h3 className="text-2xl font-semibold text-white mb-6">BuildNest™ Development</h3>
              <p className="text-gray-300 text-lg">
                Contribute to our flagship development platform that transforms complex challenges into 
                <em className="text-blue-400"> elegant solutions</em>. Build tools that developers love.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-800/90 to-gray-900/90 p-10 rounded-2xl border border-gray-600 hover:border-purple-400/50 transition-all duration-300 transform hover:scale-105 backdrop-blur-md">
              <div className="bg-purple-600/30 w-16 h-16 rounded-xl flex items-center justify-center mb-8">
                <Database className="w-8 h-8 text-purple-400" />
              </div>
              <h3 className="text-2xl font-semibold text-white mb-6">AI-Powered Analytics</h3>
              <p className="text-gray-300 text-lg">
                Pioneer groundbreaking AI-powered analytics that revolutionize data processing. 
                Turn insights into impact at enterprise scale.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Culture Section with Kruger Image */}
      <section className="relative py-24">
        <div className="absolute inset-0">
          <img 
            src="https://mocha-cdn.com/0199914d-657b-7188-b54e-12b480d8d783/Fruitful_Global_Brand_Kruger.png"
            alt="Fruitful Global Brand - Kruger Natural Environment"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-black/85 via-black/60 to-black/85"></div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl lg:text-5xl font-bold text-emerald-400 mb-8">
              🏞️ Life at FAA.ZONE™
            </h2>
            <p className="text-xl text-white max-w-4xl mx-auto font-light">
              From celebrating triumphant releases with local braais to team building at Groenkloof Nature Reserve, 
              we foster a culture where <em className="text-emerald-400">creativity flourishes</em> and innovation thrives.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="bg-gradient-to-br from-gray-800/90 to-gray-900/90 p-10 rounded-2xl border border-gray-600 backdrop-blur-md">
              <h3 className="text-2xl font-semibold text-emerald-400 mb-6">🎉 Celebrating Success</h3>
              <p className="text-gray-200 text-lg">
                We mark every milestone with local braais and community celebrations. Your achievements matter, 
                and we ensure they're recognized in style with the vibrant energy of South African culture.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-800/90 to-gray-900/90 p-10 rounded-2xl border border-gray-600 backdrop-blur-md">
              <h3 className="text-2xl font-semibold text-emerald-400 mb-6">🤝 Tech Community</h3>
              <p className="text-gray-200 text-lg">
                Host inspiring meetups and connect with the local tech ecosystem. Share <em className="text-emerald-400">fresh perspectives</em> 
                and foster innovation within our thriving Pretoria community.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      {!user && (
        <section className="py-24 bg-gradient-to-r from-emerald-900/50 to-blue-900/50 backdrop-blur-sm">
          <div className="max-w-5xl mx-auto text-center px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-8">
              Ready to Join the FAA Systems™ Ecosystem?
            </h2>
            <p className="text-xl text-gray-200 mb-12 font-light">
              Become part of the team that's building the future of enterprise technology. 
              Your journey with <em className="text-emerald-400">FAA.ZONE™</em> starts here.
            </p>
            <Link
              to="/jobs"
              className="inline-flex items-center px-12 py-6 bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 rounded-xl text-xl font-medium transition-all duration-300 transform hover:scale-105 shadow-2xl"
            >
              Start Your Journey Today
              <ArrowRight className="ml-3 w-6 h-6" />
            </Link>
          </div>
        </section>
      )}
    </div>
  );
}
