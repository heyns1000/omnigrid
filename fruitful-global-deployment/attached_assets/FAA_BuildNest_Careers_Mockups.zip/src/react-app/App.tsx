import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import HomePage from "@/react-app/pages/Home";
import JobsPage from "@/react-app/pages/Jobs";
import JobDetailPage from "@/react-app/pages/JobDetail";
import ProfilePage from "@/react-app/pages/Profile";
import ApplicationsPage from "@/react-app/pages/Applications";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import Layout from "@/react-app/components/Layout";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="/jobs" element={<JobsPage />} />
            <Route path="/jobs/:id" element={<JobDetailPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/applications" element={<ApplicationsPage />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}
