import { Building2, Grid3X3 } from "lucide-react";
import { useRef, useEffect } from "react";

export default function Footer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Footer pulse graph
    const lines: any[] = [];
    const numLines = 500;
    const pulseDuration = 3000;

    for (let i = 0; i < numLines; i++) {
      lines.push({
        offset: Math.random() * Math.PI * 2,
        amplitude: Math.random() * 0.1 + 0.01,
        frequency: Math.random() * 0.1 + 0.005,
        color: `rgba(${Math.floor(Math.random() * 50) + 10}, ${Math.floor(Math.random() * 150) + 100}, ${Math.floor(Math.random() * 50) + 200}, ${Math.random() * 0.5 + 0.1})`,
        thickness: Math.random() * 0.8 + 0.1
      });
    }

    let startTime = Date.now();

    const animate = () => {
      requestAnimationFrame(animate);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const currentTime = Date.now();
      const elapsedTime = currentTime - startTime;
      const pulseProgress = (elapsedTime % pulseDuration) / pulseDuration;
      const pulseEffect = Math.sin(pulseProgress * Math.PI * 2) * 0.8;

      for (let i = 0; i < numLines; i++) {
        const line = lines[i];
        ctx.beginPath();
        ctx.strokeStyle = line.color;
        ctx.lineWidth = line.thickness;
        ctx.lineCap = 'round';

        for (let x = 0; x <= canvas.width; x += 10) {
          const y = canvas.height / 2 +
                    Math.sin(x * line.frequency + line.offset + pulseEffect * 5) * (line.amplitude * canvas.height / 2) +
                    Math.sin(pulseProgress * Math.PI * 2 + i * 0.1) * (canvas.height / 10);

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  return (
    <footer className="relative bg-black border-t border-gray-800 min-h-[300px]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ backgroundColor: '#0d1117' }}
      />
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center text-white">
          <div className="mb-6 md:mb-0 md:w-1/3">
            <div className="flex items-center space-x-2 text-xl md:text-2xl font-bold mb-2">
              <Grid3X3 className="w-6 h-6 text-blue-400" />
              <Building2 className="w-5 h-5 text-emerald-400" />
              <span className="text-blue-400">FAA.zone</span>
              <span className="text-gray-400">/</span>
              <span className="text-emerald-400">BuildNest™</span>
            </div>
            <p className="text-gray-400 text-sm">
              © 2025 FAA.zone. All systems, symbols, and brand echoes<br />
              protected by the Omni Present Copyright™.
            </p>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-4 gap-x-8 md:gap-x-12 lg:gap-x-16">
            <div>
              <h3 className="font-bold text-gray-200 mb-2">BuildNest™</h3>
              <ul className="space-y-1 text-gray-400 text-sm">
                <li><a href="https://faa.zone/buildnest/features" className="hover:text-emerald-400 transition-colors">Features</a></li>
                <li><a href="https://faa.zone/buildnest/use-cases" className="hover:text-emerald-400 transition-colors">Use Cases</a></li>
                <li><a href="https://faa.zone/buildnest/pricing" className="hover:text-emerald-400 transition-colors">Pricing</a></li>
                <li><a href="https://faa.zone/buildnest/modules" className="hover:text-emerald-400 transition-colors">Modules</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold text-gray-200 mb-2">FAA.zone</h3>
              <ul className="space-y-1 text-gray-400 text-sm">
                <li><a href="https://faa.zone/about" className="hover:text-emerald-400 transition-colors">About FAA Systems™</a></li>
                <li><a href="https://faa.zone/omni-grid" className="hover:text-emerald-400 transition-colors">Omni Grid™</a></li>
                <li><a href="https://faa.zone/baobab-archive" className="hover:text-emerald-400 transition-colors">Compliance</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold text-gray-200 mb-2">Careers</h3>
              <ul className="space-y-1 text-gray-400 text-sm">
                <li><a href="/jobs" className="hover:text-emerald-400 transition-colors">Open Roles</a></li>
                <li><a href="https://faa.zone/careers/culture" className="hover:text-emerald-400 transition-colors">Our Culture</a></li>
                <li><a href="https://faa.zone/careers/benefits" className="hover:text-emerald-400 transition-colors">Benefits</a></li>
                <li><a href="/profile" className="hover:text-emerald-400 transition-colors">Join Our Team</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
