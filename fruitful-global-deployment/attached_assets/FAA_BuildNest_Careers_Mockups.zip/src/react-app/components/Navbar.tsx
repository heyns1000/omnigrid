import { Link, useLocation } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Building2, LogIn, LogOut, Grid3X3 } from "lucide-react";

export default function Navbar() {
  const location = useLocation();
  const { user, redirectToLogin, logout } = useAuth();

  const isActive = (path: string) => {
    if (path === "/" && location.pathname === "/") return true;
    if (path !== "/" && location.pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <nav className="bg-black/80 backdrop-blur-md border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link 
              to="/" 
              className="flex items-center space-x-3 text-xl font-bold text-emerald-400 hover:text-emerald-300 transition-colors"
            >
              <div className="flex items-center space-x-1">
                <Grid3X3 className="w-6 h-6" />
                <Building2 className="w-5 h-5" />
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-blue-400">FAA.zone</span>
                <span className="text-gray-400">/</span>
                <span className="text-emerald-400">BuildNest™</span>
              </div>
            </Link>
          </div>

          <div className="hidden md:block">
            <div className="flex items-center space-x-1">
              <Link
                to="/"
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/") 
                    ? "bg-emerald-600 text-white" 
                    : "text-gray-300 hover:text-white hover:bg-gray-800"
                }`}
              >
                Home
              </Link>
              <Link
                to="/jobs"
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/jobs") 
                    ? "bg-emerald-600 text-white" 
                    : "text-gray-300 hover:text-white hover:bg-gray-800"
                }`}
              >
                Open Roles
              </Link>
              {user && (
                <>
                  <Link
                    to="/applications"
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive("/applications") 
                        ? "bg-emerald-600 text-white" 
                        : "text-gray-300 hover:text-white hover:bg-gray-800"
                    }`}
                  >
                    My Applications
                  </Link>
                  <Link
                    to="/profile"
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive("/profile") 
                        ? "bg-emerald-600 text-white" 
                        : "text-gray-300 hover:text-white hover:bg-gray-800"
                    }`}
                  >
                    Profile
                  </Link>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  {user.google_user_data.picture && (
                    <img 
                      src={user.google_user_data.picture} 
                      alt="Profile" 
                      className="w-8 h-8 rounded-full"
                    />
                  )}
                  <span className="text-sm text-gray-300 hidden sm:block">
                    {user.google_user_data.name || user.email}
                  </span>
                </div>
                <button
                  onClick={logout}
                  className="flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-gray-800 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:block">Logout</span>
                </button>
              </div>
            ) : (
              <button
                onClick={redirectToLogin}
                className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-700 px-4 py-2 rounded-md text-sm font-medium transition-colors"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
